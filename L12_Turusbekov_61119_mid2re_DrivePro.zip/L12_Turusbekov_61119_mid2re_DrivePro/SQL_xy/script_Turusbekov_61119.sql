-- script_Turusbekov_61119.sql

-- Создание базы данных
CREATE DATABASE DriveProData;
USE DriveProData;

-- Таблица для клиентов
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица для инструкторов
CREATE TABLE instructors (
    instructor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15),
    hired_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица для автомобилей
CREATE TABLE cars (
    car_id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    license_plate VARCHAR(15) NOT NULL UNIQUE,
    instructor_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id)
);

-- Таблица для уроков вождения
CREATE TABLE driving_lessons (
    lesson_id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_name VARCHAR(100) NOT NULL,
    description TEXT,
    instructor_id INT,
    car_id INT,
    lesson_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id),
    FOREIGN KEY (car_id) REFERENCES cars(car_id)
);

-- Таблица для регистрации клиентов на уроки вождения
CREATE TABLE lesson_bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    lesson_id INT,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (lesson_id) REFERENCES driving_lessons(lesson_id)
);
