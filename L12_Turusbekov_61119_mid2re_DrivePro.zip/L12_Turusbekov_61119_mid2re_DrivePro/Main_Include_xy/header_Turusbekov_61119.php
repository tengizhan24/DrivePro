<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>DrivePro </title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<header>
    <h1>DrivePro Web site</h1>
    <p>Tengizkhan Turusbekov ID: 61119</p>
</header>
