<nav>
    <a href="start_Turusbekov.php">Home</a>
    <a href="add_customers_Turusbekov.php">Add Customer</a>
    <a href="add_instructors_Turusbekov.php">Add Instructor</a>
    <a href="add_cars_Turusbekov.php">Add Car</a>
    <a href="add_driving_lessons_Turusbekov.php">Add Driving Lesson</a>
    <a href="add_lesson_bookings_Turusbekov.php">Add Lesson Booking</a>
    <a href="see_customers_Turusbekov.php">View Customers</a>
    <a href="see_instructors_Turusbekov.php">View Instructors</a>
    <a href="see_cars_Turusbekov.php">View Cars</a>
    <a href="see_driving_lessons_Turusbekov.php">View Driving Lessons</a>
    <a href="see_lesson_bookings_Turusbekov.php">View Lesson Bookings</a>
</nav>
