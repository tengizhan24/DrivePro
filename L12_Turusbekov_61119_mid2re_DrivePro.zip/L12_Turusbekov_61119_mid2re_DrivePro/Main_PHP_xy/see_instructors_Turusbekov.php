<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Instructors</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Instructor List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Hired At</th>
        </tr>
        <?php
        $sql = "SELECT * FROM instructors";
        $stmt = $conn->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                    <td>{$row['instructor_id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['hired_at']}</td>
                </tr>";
        }
        ?>
    </table>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
