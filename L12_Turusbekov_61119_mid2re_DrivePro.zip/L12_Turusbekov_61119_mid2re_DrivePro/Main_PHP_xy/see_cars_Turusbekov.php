<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Cars</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Car List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Make</th>
            <th>Model</th>
            <th>Year</th>
            <th>License Plate</th>
            <th>Instructor ID</th>
            <th>Created At</th>
        </tr>
        <?php
        $sql = "SELECT * FROM cars";
        $stmt = $conn->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                    <td>{$row['car_id']}</td>
                    <td>{$row['make']}</td>
                    <td>{$row['model']}</td>
                    <td>{$row['year']}</td>
                    <td>{$row['license_plate']}</td>
                    <td>{$row['instructor_id']}</td>
                    <td>{$row['created_at']}</td>
                </tr>";
        }
        ?>
    </table>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
