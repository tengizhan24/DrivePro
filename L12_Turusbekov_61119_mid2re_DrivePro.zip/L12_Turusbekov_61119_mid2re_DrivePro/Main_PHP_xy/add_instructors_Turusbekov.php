<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $instructor_id = $_POST['instructor_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Check if the instructor exists
    $sql_check = "SELECT * FROM instructors WHERE instructor_id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->execute([$instructor_id]);

    if ($stmt_check->rowCount() > 0) {
        // Update the instructor's details
        $sql = "UPDATE instructors SET name = ?, email = ?, phone = ? WHERE instructor_id = ?";
        $stmt = $conn->prepare($sql);

        try {
            $stmt->execute([$name, $email, $phone, $instructor_id]);
            echo "<script>alert('Instructor details updated successfully!');</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    } else {
        // Insert new instructor
        $sql = "INSERT INTO instructors (instructor_id, name, email, phone) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        try {
            $stmt->execute([$instructor_id, $name, $email, $phone]);
            echo "<script>alert('New instructor added successfully!');</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add/Update Instructor</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Add/Update Instructor</h2>
    <form method="post">
        Instructor ID: <input type="text" name="instructor_id" required><br>
        Name: <input type="text" name="name" required><br>
        Email: <input type="email" name="email" required><br>
        Phone: <input type="text" name="phone"><br>
        <input type="submit" value="Submit">
    </form>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
