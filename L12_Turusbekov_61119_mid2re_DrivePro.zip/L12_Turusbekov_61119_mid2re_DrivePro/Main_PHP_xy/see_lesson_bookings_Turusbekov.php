<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Lesson Bookings</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Lesson Booking List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Customer ID</th>
            <th>Lesson ID</th>
            <th>Booking Date</th>
        </tr>
        <?php
        $sql = "SELECT * FROM lesson_bookings";
        $stmt = $conn->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                    <td>{$row['booking_id']}</td>
                    <td>{$row['customer_id']}</td>
                    <td>{$row['lesson_id']}</td>
                    <td>{$row['booking_date']}</td>
                </tr>";
        }
        ?>
    </table>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
