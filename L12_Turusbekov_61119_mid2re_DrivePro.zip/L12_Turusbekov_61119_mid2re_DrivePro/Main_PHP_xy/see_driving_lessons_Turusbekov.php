<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Driving Lessons</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Driving Lesson List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Instructor ID</th>
            <th>Car ID</th>
            <th>Lesson Date</th>
            <th>Created At</th>
        </tr>
        <?php
        $sql = "SELECT * FROM driving_lessons";
        $stmt = $conn->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                    <td>{$row['lesson_id']}</td>
                    <td>{$row['lesson_name']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['instructor_id']}</td>
                    <td>{$row['car_id']}</td>
                    <td>{$row['lesson_date']}</td>
                    <td>{$row['created_at']}</td>
                </tr>";
        }
        ?>
    </table>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
