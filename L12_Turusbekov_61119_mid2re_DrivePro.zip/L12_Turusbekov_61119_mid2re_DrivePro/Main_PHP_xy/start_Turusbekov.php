<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');
include('../Main_Include_xy/header_Turusbekov_61119.php');
include('../Main_Include_xy/navigation_Turusbekov_61119.php');
?>

<div class="container">
    <h1>Welcome to DrivePro</h1>
    <!-- <p>This is the main page of the DrivePro driving school management system.</p> -->
    
    <div id="carousel" class="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../IMG/img2.jpg" alt="Image 1">
            </div>
            <div class="carousel-item">
                <img src="../IMG/img3.jpg" alt="Image 2">
            </div>
            <div class="carousel-item">
                <img src="../IMG/img3.webp" alt="Image 3">
            </div>
        </div>
        <a class="carousel-control prev" onclick="prevSlide()">&#10094;</a>
        <a class="carousel-control next" onclick="nextSlide()">&#10095;</a>
    </div>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>

<script>
let currentIndex = 0;

function showSlide(index) {
    const slides = document.querySelectorAll('.carousel-item');
    if (index >= slides.length) {
        currentIndex = 0;
    } else if (index < 0) {
        currentIndex = slides.length - 1;
    } else {
        currentIndex = index;
    }
    const offset = -currentIndex * 100;
    document.querySelector('.carousel-inner').style.transform = `translateX(${offset}%)`;
}

function nextSlide() {
    showSlide(currentIndex + 1);
}

function prevSlide() {
    showSlide(currentIndex - 1);
}

document.addEventListener('DOMContentLoaded', () => {
    showSlide(currentIndex);
});
</script>
