<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_POST['customer_id'];
    $lesson_id = $_POST['lesson_id'];

    $sql = "INSERT INTO lesson_bookings (customer_id, lesson_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$customer_id, $lesson_id]);

    echo "New lesson booking added successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Lesson Booking</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Add New Lesson Booking</h2>
    <form method="post">
    <p>Write the instructor ID correctly</p>
        Customer ID: <input type="number" name="customer_id" required><br>
        <p>Write the Car ID correctly</p>
        Lesson ID: <input type="number" name="lesson_id" required><br>
        <input type="submit" value="Add Lesson Booking">
    </form>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
