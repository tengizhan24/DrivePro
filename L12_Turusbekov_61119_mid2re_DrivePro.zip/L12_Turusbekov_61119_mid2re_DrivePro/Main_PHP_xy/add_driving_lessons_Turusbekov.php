<?php
include('../DB_Include_xy/db_info_Turusbekov_61119.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lesson_name = $_POST['lesson_name'];
    $description = $_POST['description'];
    $instructor_id = $_POST['instructor_id'];
    $car_id = $_POST['car_id'];
    $lesson_date = $_POST['lesson_date'];

    $sql = "INSERT INTO driving_lessons (lesson_name, description, instructor_id, car_id, lesson_date) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$lesson_name, $description, $instructor_id, $car_id, $lesson_date]);

    echo "New driving lesson added successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Driving Lesson</title>
    <link rel="stylesheet" type="text/css" href="../CSS_xy/style_Turusbekov_61119.css">
</head>
<body>
<?php include('../Main_Include_xy/header_Turusbekov_61119.php'); ?>
<?php include('../Main_Include_xy/navigation_Turusbekov_61119.php'); ?>

<div class="container">
    <h2>Add New Driving Lesson</h2>
    <form method="post">
        Lesson Name: <input type="text" name="lesson_name" required><br>
        Description: <textarea name="description" required></textarea><br>
        <p>Write the instructor ID correctly</p>
        Instructor ID: <input type="number" name="instructor_id" required><br>
        <p>Write the Car ID correctly</p>
        Car ID: <input type="number" name="car_id" required><br>
        Lesson Date: <input type="date" name="lesson_date" required><br>
        <input type="submit" value="Add Driving Lesson">
    </form>
</div>

<?php include('../Main_Include_xy/footer_Turusbekov_61119.php'); ?>
</body>
</html>
